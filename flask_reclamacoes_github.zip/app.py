from flask import Flask, render_template, request, redirect, url_for, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SECRET_KEY'] = 'supersecretkey'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///reclamacoes.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)

class Reclamacao(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    mensagem = db.Column(db.Text, nullable=False)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

with app.app_context():
    db.create_all()

@app.route('/')
@login_required
def index():
    return render_template('index.html')

@app.route('/salvar', methods=['POST'])
@login_required
def salvar():
    nome = request.form['nome']
    mensagem = request.form['mensagem']
    nova_reclamacao = Reclamacao(nome=nome, mensagem=mensagem)
    db.session.add(nova_reclamacao)
    db.session.commit()
    return redirect(url_for('listar'))

@app.route('/listar')
@login_required
def listar():
    reclamacoes = Reclamacao.query.all()
    return render_template('lista.html', reclamacoes=reclamacoes)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for('index'))
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = generate_password_hash(request.form['password'], method='sha256')
        if User.query.filter_by(username=username).first() is None:
            new_user = User(username=username, password=password)
            db.session.add(new_user)
            db.session.commit()
            return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/api/reclamacoes', methods=['GET'])
@login_required
def api_listar():
    reclamacoes = Reclamacao.query.all()
    return jsonify([{ 'id': r.id, 'nome': r.nome, 'mensagem': r.mensagem } for r in reclamacoes])

@app.route('/api/reclamacoes', methods=['POST'])
@login_required
def api_criar():
    data = request.get_json()
    nova = Reclamacao(nome=data['nome'], mensagem=data['mensagem'])
    db.session.add(nova)
    db.session.commit()
    return jsonify({'message': 'Reclamação criada com sucesso'}), 201

@app.route('/api/reclamacoes/<int:id>', methods=['DELETE'])
@login_required
def api_deletar(id):
    reclamacao = Reclamacao.query.get_or_404(id)
    db.session.delete(reclamacao)
    db.session.commit()
    return jsonify({'message': 'Reclamação deletada com sucesso'})

if __name__ == '__main__':
    app.run(debug=True)
