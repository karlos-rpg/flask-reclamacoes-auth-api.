# Sistema de Reclamações com Flask

Este projeto é um site para registro de reclamações com autenticação e API REST.

## Funcionalidades
- Cadastro e login de usuários
- Envio e listagem de reclamações
- API REST para integração (listar, criar, deletar reclamações)

## Como rodar
1. Clone o repositório:
   ```bash
   git clone https://github.com/seuusuario/flask-reclamacoes-auth-api.git
   ```
2. Instale as dependências:
   ```bash
   pip install -r requirements.txt
   ```
3. Execute:
   ```bash
   python app.py
   ```
4. Acesse:
   ```
   http://127.0.0.1:5000
   ```

## Endpoints da API
- **GET** `/api/reclamacoes`
- **POST** `/api/reclamacoes`
- **DELETE** `/api/reclamacoes/<id>`
